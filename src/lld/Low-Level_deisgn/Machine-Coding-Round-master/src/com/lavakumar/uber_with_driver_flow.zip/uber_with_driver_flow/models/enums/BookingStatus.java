package com.lavakumar.uber_with_driver_flow.models.enums;

public enum BookingStatus {
    CREATED,
    STARTED,
    ENDED
}
